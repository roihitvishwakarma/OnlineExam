<x-admin.admin-layout>
  <x-slot name="adminTitle">Create Exam</x-slot>
  <x-slot name="css">admin/css/createExam.css</x-slot>
  <x-slot name="adminBodyContent">
    <form action="{{route('createexam')}}" method="post" id="createExamFormContainer">
      @csrf
      <h2 id="heading">Create Exam</h2>
      <p style="margin-bottom: 1.5%">Who can give exam</p>

      <div id="whoCanGiveExamMenu">
        <input type="radio" id="allStudents" checked="checked" name="whoCanGiveExamRadio" value="all">
        <label for="html">All students</label>
        <input type="radio" id="customStudents" name="whoCanGiveExamRadio" value="custom">
        <label for="html">Custom select</label><br>
      </div>
      <div id="specifyRollNumberDiv">
        <input type="text" name="forstudent" id="rollNoInputArea" placeholder="Enter roll number seprated by ( , ) eg: 1,2,3,...">
      </div>
      <div id="marksAndSubjectContainer">
        <div id="marksContainer">
          <p style="margin-bottom: 1%">Marks: </p>
          <input type="number" name="marks" required="required" placeholder="Total" id="totalNumberOfMarks">
        </div>
        <div id="marksContainer">
          <p style="margin-bottom: 1%">Subject:</p>
          <input type="text" name="subject" required="required" placeholder="Enter here" id="subjectInput">
        </div>
        <div id="marksContainer">
          <p style="margin-bottom: 1%">Date:</p>
          <input type="date" name="examdate" required="required" placeholder="Enter here" id="examDate">
        </div>
        <div id="marksContainer">
          <p style="margin-bottom: 1%">Start at:</p>
          <input type="time" name="starttime" required="required" placeholder="Enter here" id="startTime">
        </div>
        <div id="marksContainer">
          <p style="margin-bottom: 1%">Ends at:</p>
          <input type="time" name="endtime" required="required" placeholder="Enter here" id="endTime">
        </div>
      </div>
      {{-- <input type="number" placeholder="Total marks" id="totalMarks"> --}}
      <hr>
       <div class="questionContainer">
        {{-- <div class="questionSubContainer">
         <p class='questionNumbering'>1</p>
         <input type="text" placeholder="Question" class="question">
         <input type="text" placeholder="Option-1" class="option" name="option">
         <input type="text" placeholder="Option-2" class="option" name="option">
         <input type="text" placeholder="Option-3" class="option" name="option">
         <input type="text" placeholder="Option-4" class="option" name="option">
         <input type="text" placeholder="Answer" class="option" name="answer">
        </div> --}}
        {{-- <div class="questionSubContainer">
         <p class='questionNumbering'>1</p>
         <input type="text" placeholder="Question" class="question">
         <input type="text" placeholder="Option" class="option">
         <input type="text" placeholder="Option" class="option">
         <input type="text" placeholder="Option" class="option">
         <input type="text" placeholder="Option" class="option">
        </div> --}}
       </div>
      <button type="button" class="btn btn-outline-secondary" id="addBtn">Insert Question</button>
      <div id="submitButtonContainer">
        {{-- <button type="submit" class="btn btn-outline-primary" data-bs-toggle="button" id="submitBtn">Submit</button> --}}
        <button type="submit" name="numberofquestions" class="btn btn-outline-primary"  id="submitBtn">Submit</button>
      </div>
    </form>
  </x-slot>
  <x-slot name="adminJs">admin/js/createExam.js</x-slot>
</x-admin.admin-layout>