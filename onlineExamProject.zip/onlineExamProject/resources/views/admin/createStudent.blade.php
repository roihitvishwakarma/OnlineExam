<x-admin.admin-layout>
  <x-slot name="adminTitle">Create Student</x-slot>
  <x-slot name="css">admin/css/createStudent.css</x-slot>
  <x-slot name="adminBodyContent">
    <div id="createButtonStudentDiv">
      <button id="createStudentButton" type="button" class="btn btn-warning btn-lg">Create student</button>
    </div>

    @isset($e)
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Error!</strong>all fields must be require.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endisset

    <form id="createStudentFormContainer" action="{{route('createstudent')}}" method="post">
      @csrf
      <h2>Create new student</h2>
      <input type="text" required="required" class="createStudentInputFieldClass" name="fullname" placeholder="Full Name"> 
      <input type="email" required="required" class="createStudentInputFieldClass" placeholder="Email" name="email">
      <input type="text" required="required" class="createStudentInputFieldClass" name="class" placeholder="Class"> <input type="text"
        class="createStudentInputFieldClass" required="required" name="rollno" placeholder="Rollno">
      <input type="text" class="createStudentInputFieldClass" required="required" name="div" placeholder="Div"> <input type="text"
        class="createStudentInputFieldClass" name="dob" required="required" placeholder="Date of birth YYYY-MM-DD">
      <input type="password" required="required" class="createStudentInputFieldClass" name="password" placeholder="Password">

      <div id="submitButtonId">
        <button type="submit" class="btn btn-outline-success">Submit</button>
      </div>
    </form>

    <div id="studentListContainer">
     <h2 id="studentListContainerHeading">All students</h2>
     <div id="studentListHeading">
      <p class="studentListHeadingText">Name</p>
      <p class="studentListHeadingText">Rollno</p>
      <p class="studentListHeadingText">Class</p>
      <p class="studentListHeadingText">Division</p>
      <p class="studentListHeadingText">DOB</p>
     </div>

     @foreach ($studentList as $data)
       <div class="studentListCard">
        <p class="studentListCardData nameData">{{$data->name}}</p>
        <p class="studentListCardData rollnoData">{{$data->rollno}}</p>
        <p class="studentListCardData classData">{{$data->class}}</p>
        <p class="studentListCardData divisionData">{{$data->div}}</p>
        <p class="studentListCardData dobData">{{$data->dob}}</p>
       </div>
     @endforeach
     {{-- <div class="studentListCard">
      <p class="studentListCardData nameData">Rohit vishwakarma</p>
      <p class="studentListCardData rollnoData">TCS-03</p>
      <p class="studentListCardData classData">TCS</p>
      <p class="studentListCardData divisionData">A</p>
      <p class="studentListCardData dobData">1998-11-14</p>
     </div> --}}
    </div>
  </x-slot>
  <x-slot name="adminJs">admin/js/createStudent.js</x-slot>
</x-admin.admin-layout>