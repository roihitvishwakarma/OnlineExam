<x-base-layout>
  <x-slot name="title">Home</x-slot>
  <x-slot name="css">css/home.css</x-slot>
  {{-- <x-slot name="script">js/home.js</x-slot> --}}
  
  <x-slot name="bodyContent">
    <h2 id="upcomingEaxmHeading">Upcoming Exam</h2>
    <div id="sheduleExamParentContainer">
      @foreach ($examlist as $exams)
      @php

          $startTimeSub = substr($exams->starttime,0,5);
          $endTimeSub = substr($exams->endtime,0,5);
          $today = time();

          $sdate = explode("-",$exams->examdate);
          $stime = explode(":",$exams->starttime);
          $etime = explode(":",$exams->endtime);

          $startDateTime = mktime($stime[2],$stime[1],$stime[0], $sdate[1],$sdate[2],$sdate[0]);
          $endDateTime = mktime($etime[2],$etime[1],$etime[0], $sdate[1],$sdate[2],$sdate[0]);
          
      @endphp
          <form action="{{route('startexam')}}" method="post" class='sheduledExamCard'>
            @csrf
            <div class='sheduledExamCardDetails'>
             <p><b>Subject: </b> {{$exams->subject}}</p>
             <p><b>Date: </b> {{$exams->examdate}}</p>
             <p><b>Time:</b> {{$startTimeSub}} To {{$endTimeSub}}</p>
             <p><b>Marks: </b> {{$exams->marks}}</p>
            </div>
            <button type='submit' name="startExamButton" class='btn btn-outline-primary' value="{{$exams->id}}" data-examid='{{$exams->id}}'  id='startButton' >Start</button>
          </form>
      @endforeach

      <div id="examListHeadingDiv">
        <h2 id="examListHeading">Exam list & result</h2>
      </div>
      <div id="resultParentContainer">
        {{-- <h2 id="examListHeading">Exam list & result</h2> --}}
        <div class="resultContainer">
          <div>
            <p><b>Subject:</b> Science</p>
            <p><b>Date:</b> 14-12-2014</p>
            <p><b>Time:</b> 14:00 - 15:00</p>
            <p><b>Marks:</b> 100</p>
          </div>

          <div>
            <p><b>Name:</b> rohit vishwakarma</p>
            <p><b>Rollno:</b> 52</p>
            <p><b>Marks:</b> 80</p>
            <p><b>Result:</b> pass</p>
          </div>
        </div>
      </div>
  </x-slot>

  <x-slot name="scripts">
    <script>
   $(document).ready(function(e){
    // console.log("HELolo");
    //  $("#startButton").on("click", function(){
    //      console.log($(this).data('examid'))
    //  })
     $(document).on("click", "#startButton", function(){
        //  console.log($(this).data('examid'));
        console.log($(this).data('examid'));
        console.log($(this).val());
         var examid = $(this).data('examid');

         $.ajax({
          headers:{
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
         });

         $.ajax({
             url:"/startexam",
             method:"POST",
             data:{examId:examid},
             success:function(response){
               console.log(response);
             }
         })
     })
      })
      </script>
  </x-slot>
    
</x-base-layout>



