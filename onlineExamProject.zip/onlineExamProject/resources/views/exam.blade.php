<x-base-layout>
    <x-slot name="title">Exam</x-slot>
    <x-slot name="css">css/exam.css</x-slot>
    {{-- <x-slot name="script">js/exam.js</x-slot> --}}
    <x-slot name="bodyContent">
     
      {{-- @php
          print_r($question->question);
      @endphp --}}
      @php
      $questions = 0;
      @endphp
      
      <form action="{{route('sumbitexam')}}" method="post" id="formId">
        @csrf
        <div>
         <h2 style="text-align:center">{{$subjectName}}</h2>
         <div id="examFormSubHeadingPart">
          <h5 name="marks" value="{{$marks}}">Marks: {{$marks}}</h5>
          <h5>Time: {{substr($startTime,0,5)." To ".substr($endTime,0,5)}}</h5>
         </div>
        </div>
        <hr>
        
      
      @foreach ($questionlist as $question)
      @php
          $questions = $questions + 1;
      @endphp
      <div id="QuestionsId">
        <p style="margin-left: 1%; margin-bottom: 0.8%">{{$question->question}}</p>
        <div id='options'>
          <div class='optionsSubSection1'>
           <div class='questionTextClass'>
            <input style="display:none" name="examid" value="{{$question->examid}}">
            <input style="display:none" name="marks" value="{{$question->marks}}">
            <input type='radio' name='option1_{{$questions}}' value='{{$question->option1}}'><span style='margin-left: 2%;'>{{$question->option1}}</span>
           </div>
           <div class='questionTextClass'>
            <input type='radio' name='option1_{{$questions}}' value='{{$question->option2}}'><span style='margin-left: 2%;'>{{$question->option2}}</span>
           </div>
          </div>
          <div class='optionsSubSection1'>
           <div class='questionTextClass'>
            <input type='radio' name='option1_{{$questions}}' value='{{$question->option3}}'><span style='margin-left: 2%;'>{{$question->option3}}</span>
           </div>
           <div class='questionTextClass'>
            <input type='radio' name='option1_{{$questions}}' value='{{$question->option4}}'><span style='margin-left: 2%;'>{{$question->option4}}</span>
           </div>
          </div>
        </div>
      </div>
  
    @endforeach
    <input style="display:none" name="numberofquestions" value="{{$questions}}">
            {{-- <p>1. This is a First Qustion</p>
          <div class="options">
            <div class="optionsSubSection1">
             <div class="questionTextClass">
              <input type="radio" name="question1" value="animal"><span style="margin-left: 2%;">Lorem ipsum dolor sit amet consectetur, adipisicing</span>
             </div>
             <div class="questionTextClass">
              <input type="radio" name="question1" value="human"><span style="margin-left: 2%;">Lorem r sit amet consectetur, adipisicing elit</span>
             </div>
            </div>
            <div class="optionsSubSection1">
             <div class="questionTextClass">
              <input type="radio" name="question1" value="alien"><span style="margin-left: 2%;">Lorem ipsum dolor sit amet consectetur, adipisicing</span>
             </div>
             <div class="questionTextClass">
              <input type="radio" name="question1" value="NA"><span style="margin-left: 2%;">L amet consectetur, adipisicing elit</span>
             </div>
            </div>
          </div>
        </div> --}}
        <div id="submitBtnDiv">
         <button type="submit" id="submitButton" value="{{$question->examid}}" class="btn btn-outline-success">Submit</button>
        </div>
        </form>
    </x-slot>
</x-base-layout>