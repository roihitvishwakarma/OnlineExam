<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class examController extends Controller
{
    
    function show(Request $request){
       $examid = $request->startExamButton;
    //    global $examid;
        $fetcToStartExam = DB::table('exams')
        ->join('questions','exams.id','=','questions.examid')
        ->select('questions.*','exams.*')
        ->where('questions.examid','=',$request->startExamButton)
        ->get();

        return view("exam",['questionlist'=>$fetcToStartExam, 'subjectName'=>$fetcToStartExam[0]->subject, 'marks'=>$fetcToStartExam[0]->marks, 'startTime'=>$fetcToStartExam[0]->starttime, 'endTime'=>$fetcToStartExam[0]->endtime,]);
    }
   
    function submitexam(Request $request){
        // echo $request->option1_1;  
        // echo $request->examid;  
        // echo $request->marks;  
        // echo $request->numberofquestions;
        // for($i=0; $i<5; $i++){

        // }
        // echo  $request->option1_2;
        // for($i=0; $i<$request->numberofquestions; $i++){
        //     $value = $request->option1_.$i;
        //     DB::insert("insert into answerbystudent (examid, rollno, answerbystudent) values(?,?,?)",
        //         [$request->examid, Auth::user()->rollno, $value]);
        // }
        // $fetcToStartExam = DB::table('results')
        // ->join('answerbystudent','results.id','=','answerbystudent.examid','results.rollno','=','answerbystudent.rollno')
        // ->select('answerbystudent.*','results.*')
        // ->where('answerbystudent.examid','=',$request->examid)
        // ->get();


        // $fetchData = DB::select("select answer from questions where examid=?",[$request->examid]);
    //    DB::insert("insert into results (examid, rollno, obtainedmark, result, answerbystudent) values(?,?,?,?,?)",
    //             [$request->examid, Auth::user()->rollno, $request->marks, 'pass', $request->option1_+$i]);
    }
}
