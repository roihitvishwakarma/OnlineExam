<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
// Hash::make(12345678)

class homeController extends Controller
{
    function show(){
        $today = time();
        $examList = DB::select("select * from exams order by examdate");

        return view('home',['examlist'=>$examList]);
    }

    
}
