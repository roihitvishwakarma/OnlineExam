<?php

namespace App\Http\Controllers\adminControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class createStudentControllers extends Controller
{
    function show()
    {
        $fetchedData = DB::select("select * from users where usertype= ? order by rollno",[0]);
        // dd($fetchedData);
        return view('admin.createStudent',['studentList'=>$fetchedData]);
    }

    function createStudent(Request $request)
    {
        try
        {
        $student = new User;
        $student->name=$request->fullname;
        $student->email=$request->email;
        $student->class=10;
        $student->dob=$request->dob;
        $student->rollno=$request->rollno;
        $student->div=$request->div;
        $student->password=Hash::make($request->password);
        $student->save();

        return redirect('createstudent');
        }
        catch(Exception $e)
        {
            return view('admin.createStudent',['errorMsg'=>$e]);
        }
    }
}
