<?php

namespace App\Http\Controllers\adminControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\admin\Exam;
use App\Models\admin\Question;
use Illuminate\Support\Facades\DB;

class createExamControllers extends Controller
{
    function show(){
        return view('admin.createExam');
    }
    
    function createExam(Request $request){
        $examTable = new Exam;
        $questionTable = new Question;

        $examTable->subject=$request->subject;
        $examTable->marks=$request->marks;
        $examTable->examdate=$request->examdate;
        $examTable->starttime=$request->starttime;
        $examTable->endtime=$request->endtime;
        
        $customstu = false;
        $whoCanGiveExam = $request->whoCanGiveExamRadio;
        if($whoCanGiveExam == 'custom'){
          $examTable->forstudent='custom';
          $customstu = true;
        }else{
          $examTable->forstudent='all';
          $customstu = false;
        }

        $insertToExam = $examTable->save();

        if($insertToExam)
        {
          $recentEnteredRecord;
          
          $fetchedFromExam = DB::select("select id from exams order by id asc");
          foreach($fetchedFromExam as $data)
          {
            $recentEnteredRecord = $data->id;
          }
          
          $numberOfQuestions = $request->numberofquestions;

          for($i=1; $i<=$numberOfQuestions; $i++)
          {
            $question = 'question'.strval($i);
            $option1 = 'option'.strval($i).'_1';
            $option2 = 'option'.strval($i).'_2';
            $option3 = 'option'.strval($i).'_3';
            $option4 = 'option'.strval($i).'_1';
            $answer = 'answer'.strval($i);


            DB::insert('insert into questions (examid, question, option1, option2, option3, option4, answer)
                values(?, ?, ?, ?, ?, ?, ?)',[$recentEnteredRecord, $request->$question, $request->$option1, $request->$option2, $request->$option3, $request->$option4, $request->$answer]);

          }

          if($customstu){
            $customArrayValues = explode(",",$request->forstudent);
            for($i=0; $i<sizeof($customArrayValues); $i++){
              DB::insert('insert into customstudents (examid, rollno) values(?,?)',[$recentEnteredRecord, $customArrayValues[$i]]);
            }
          }
            return view('admin.createExam');
        }
    }
}
