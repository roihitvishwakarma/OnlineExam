<?php

namespace App\Http\Controllers\adminControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class adminPanelControllers extends Controller
{
    function show(){
        if(Auth::user()->usertype == 0){
            return view('home');
        }else if(Auth::user()->usertype == 1){

         $examList = DB::select("select * from exams order by examdate");
         return view('admin.adminpanel', ['examlist'=>$examList]);
        }
    }
}
