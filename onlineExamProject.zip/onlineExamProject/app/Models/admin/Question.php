<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    use HasFactory;

    protected $fillable = [
        'examid',
        'question',
        'option1',
        'option2',
        'option3',
        'option4',
        'answer',
    ];
}
