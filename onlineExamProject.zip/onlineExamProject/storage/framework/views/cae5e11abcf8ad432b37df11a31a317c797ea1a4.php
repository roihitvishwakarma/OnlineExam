<?php if (isset($component)) { $__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\AdminLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Admin\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('adminTitle', null, []); ?> Admin Panel <?php $__env->endSlot(); ?>
     <?php $__env->slot('css', null, []); ?> admin/css/adminPanel.css <?php $__env->endSlot(); ?>
     <?php $__env->slot('adminJs', null, []); ?> admin/js/adminPanel.js <?php $__env->endSlot(); ?>
     <?php $__env->slot('adminBodyContent', null, []); ?> 
        <div class="examListContainer">
         <h2 id="examListContainerHeading">Exam list</h2>
         <div id="examListContainerHeadingBar">
           <p class="examListHeadingText">Srno</p>
           <p class="examListHeadingText">Subject</p>
           <p class="examListHeadingText">Date</p>
           <p class="examListHeadingText">Time</p>
           <p class="examListHeadingText">Class</p>
           <p class="examListHeadingText">Divion</p>
           <p class="examListHeadingText">Total Marks</p>
           
         </div>
           <?php
               $srno=0;
           ?>
         <?php $__currentLoopData = $examlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="examDetailsCard">
            <p id="examListSrText"><?php echo $srno=$srno+1; ?></p>
            <p id="examListSubjectText"><?php echo e($exams->subject); ?></p>
            <p id="examListDateText"><?php echo e($exams->examdate); ?></p>
              <p id="examListTimeText"><?php echo e($exams->starttime); ?>-<?php echo e($exams->endtime); ?></p>
            <p id="examListClassText">10th</p>
            <p id="examListDivisonText">A</p>
            <p id="examListTotalStudentsText"><?php echo e($exams->marks); ?></p>
            
            <button type="button" class="btn btn-outline-warning" data-examid="<?php echo e($exams->id); ?>" id="resultButton">Result</button>
           </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         

         <div class="viewButtonContainerView">
          <div class="studentResultViewHeadingBar">
            <p>Rollno</p>
            <p>Name</p>
            <p>Submitted at</p>
            <p>Marks</p>
            <p>Status</p>
          </div>
          <div class="studentResultViewResult">
            <p id="studentResultRollno">1</p>
            <p id="studentResultName">Rohit vishwakarma</p>
            <p id="studentResultSubmittedat">14:00</p>
            <p id="studentResultMarks">80</p>
            <p id="studentResultStatus">Pass</p>
          </div>
         </div>
        </div>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451)): ?>
<?php $component = $__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451; ?>
<?php unset($__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451); ?>
<?php endif; ?><?php /**PATH C:\Web developement_VS code\laravel\onlineExamProject\resources\views/admin/adminpanel.blade.php ENDPATH**/ ?>