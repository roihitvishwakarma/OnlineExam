<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<?php if(isset($css)): ?>
 <link href="<?php echo e(asset($css)); ?>" rel="stylesheet">
<?php endif; ?>
<?php if(isset($adminTitle)): ?>
  <title><?php echo e($adminTitle); ?></title>
<?php endif; ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    
      <?php echo $__env->make('layouts.admin.adminNavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


   <?php if(isset($adminBodyContent)): ?>   
   <?php echo e($adminBodyContent); ?>

    <?php echo e($slot); ?>

   <?php endif; ?>
</body>
<!-- JavaScript Bundle with Popper -->
<script src="js/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
<?php if(isset($adminJs)): ?>
<script src="<?php echo e($adminJs); ?>"></script>    
<?php endif; ?>

</html><?php /**PATH C:\Web developement_VS code\laravel\onlineExamProject\resources\views/components/admin/admin-layout.blade.php ENDPATH**/ ?>