<?php if (isset($component)) { $__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\AdminLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Admin\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('adminTitle', null, []); ?> Create Exam <?php $__env->endSlot(); ?>
   <?php $__env->slot('css', null, []); ?> admin/css/createExam.css <?php $__env->endSlot(); ?>
   <?php $__env->slot('adminBodyContent', null, []); ?> 
    <form action="<?php echo e(route('createexam')); ?>" method="post" id="createExamFormContainer">
      <?php echo csrf_field(); ?>
      <h2 id="heading">Create Exam</h2>
      <p style="margin-bottom: 1.5%">Who can give exam</p>

      <div id="whoCanGiveExamMenu">
        <input type="radio" id="allStudents" checked="checked" name="whoCanGiveExamRadio" value="all">
        <label for="html">All students</label>
        <input type="radio" id="customStudents" name="whoCanGiveExamRadio" value="custom">
        <label for="html">Custom select</label><br>
      </div>
      <div id="specifyRollNumberDiv">
        <input type="text" name="forstudent" id="rollNoInputArea" placeholder="Enter roll number seprated by ( , ) eg: 1,2,3,...">
      </div>
      <div id="marksAndSubjectContainer">
        <div id="marksContainer">
          <p style="margin-bottom: 1%">Marks: </p>
          <input type="number" name="marks" required="required" placeholder="Total" id="totalNumberOfMarks">
        </div>
        <div id="marksContainer">
          <p style="margin-bottom: 1%">Subject:</p>
          <input type="text" name="subject" required="required" placeholder="Enter here" id="subjectInput">
        </div>
        <div id="marksContainer">
          <p style="margin-bottom: 1%">Date:</p>
          <input type="date" name="examdate" required="required" placeholder="Enter here" id="examDate">
        </div>
        <div id="marksContainer">
          <p style="margin-bottom: 1%">Start at:</p>
          <input type="time" name="starttime" required="required" placeholder="Enter here" id="startTime">
        </div>
        <div id="marksContainer">
          <p style="margin-bottom: 1%">Ends at:</p>
          <input type="time" name="endtime" required="required" placeholder="Enter here" id="endTime">
        </div>
      </div>
      
      <hr>
       <div class="questionContainer">
        
        
       </div>
      <button type="button" class="btn btn-outline-secondary" id="addBtn">Insert Question</button>
      <div id="submitButtonContainer">
        
        <button type="submit" name="numberofquestions" class="btn btn-outline-primary"  id="submitBtn">Submit</button>
      </div>
    </form>
   <?php $__env->endSlot(); ?>
   <?php $__env->slot('adminJs', null, []); ?> admin/js/createExam.js <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451)): ?>
<?php $component = $__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451; ?>
<?php unset($__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451); ?>
<?php endif; ?><?php /**PATH C:\Web developement_VS code\laravel\onlineExamProject\resources\views/admin/createExam.blade.php ENDPATH**/ ?>