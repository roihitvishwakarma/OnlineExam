<?php if (isset($component)) { $__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BaseLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\BaseLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> Home <?php $__env->endSlot(); ?>
   <?php $__env->slot('css', null, []); ?> css/home.css <?php $__env->endSlot(); ?>
  
  
   <?php $__env->slot('bodyContent', null, []); ?> 
    <h2 id="upcomingEaxmHeading">Upcoming Exam</h2>
    <div id="sheduleExamParentContainer">
      <?php $__currentLoopData = $examlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php

          $startTimeSub = substr($exams->starttime,0,5);
          $endTimeSub = substr($exams->endtime,0,5);
          $today = time();

          $sdate = explode("-",$exams->examdate);
          $stime = explode(":",$exams->starttime);
          $etime = explode(":",$exams->endtime);

          $startDateTime = mktime($stime[2],$stime[1],$stime[0], $sdate[1],$sdate[2],$sdate[0]);
          $endDateTime = mktime($etime[2],$etime[1],$etime[0], $sdate[1],$sdate[2],$sdate[0]);
          
      ?>
          <form action="<?php echo e(route('startexam')); ?>" method="post" class='sheduledExamCard'>
            <?php echo csrf_field(); ?>
            <div class='sheduledExamCardDetails'>
             <p><b>Subject: </b> <?php echo e($exams->subject); ?></p>
             <p><b>Date: </b> <?php echo e($exams->examdate); ?></p>
             <p><b>Time:</b> <?php echo e($startTimeSub); ?> To <?php echo e($endTimeSub); ?></p>
             <p><b>Marks: </b> <?php echo e($exams->marks); ?></p>
            </div>
            <button type='submit' name="startExamButton" class='btn btn-outline-primary' value="<?php echo e($exams->id); ?>" data-examid='<?php echo e($exams->id); ?>'  id='startButton' >Start</button>
          </form>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <div id="examListHeadingDiv">
        <h2 id="examListHeading">Exam list & result</h2>
      </div>
      <div id="resultParentContainer">
        
        <div class="resultContainer">
          <div>
            <p><b>Subject:</b> Science</p>
            <p><b>Date:</b> 14-12-2014</p>
            <p><b>Time:</b> 14:00 - 15:00</p>
            <p><b>Marks:</b> 100</p>
          </div>

          <div>
            <p><b>Name:</b> rohit vishwakarma</p>
            <p><b>Rollno:</b> 52</p>
            <p><b>Marks:</b> 80</p>
            <p><b>Result:</b> pass</p>
          </div>
        </div>
      </div>
   <?php $__env->endSlot(); ?>

   <?php $__env->slot('scripts', null, []); ?> 
    <script>
   $(document).ready(function(e){
    // console.log("HELolo");
    //  $("#startButton").on("click", function(){
    //      console.log($(this).data('examid'))
    //  })
     $(document).on("click", "#startButton", function(){
        //  console.log($(this).data('examid'));
        console.log($(this).data('examid'));
        console.log($(this).val());
         var examid = $(this).data('examid');

         $.ajax({
          headers:{
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
         });

         $.ajax({
             url:"/startexam",
             method:"POST",
             data:{examId:examid},
             success:function(response){
               console.log(response);
             }
         })
     })
      })
      </script>
   <?php $__env->endSlot(); ?>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a)): ?>
<?php $component = $__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a; ?>
<?php unset($__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a); ?>
<?php endif; ?>



<?php /**PATH C:\Web developement_VS code\laravel\onlineExamProject\resources\views/home.blade.php ENDPATH**/ ?>