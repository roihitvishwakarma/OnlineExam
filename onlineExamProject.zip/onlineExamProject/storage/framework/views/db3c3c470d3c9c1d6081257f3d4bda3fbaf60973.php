<?php if (isset($component)) { $__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BaseLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\BaseLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Exam <?php $__env->endSlot(); ?>
     <?php $__env->slot('css', null, []); ?> css/exam.css <?php $__env->endSlot(); ?>
    
     <?php $__env->slot('bodyContent', null, []); ?> 
     
      
      <?php
      $questions = 0;
      ?>
      
      <form action="<?php echo e(route('sumbitexam')); ?>" method="post" id="formId">
        <?php echo csrf_field(); ?>
        <div>
         <h2 style="text-align:center"><?php echo e($subjectName); ?></h2>
         <div id="examFormSubHeadingPart">
          <h5 name="marks" value="<?php echo e($marks); ?>">Marks: <?php echo e($marks); ?></h5>
          <h5>Time: <?php echo e(substr($startTime,0,5)." To ".substr($endTime,0,5)); ?></h5>
         </div>
        </div>
        <hr>
        
      
      <?php $__currentLoopData = $questionlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
          $questions = $questions + 1;
      ?>
      <div id="QuestionsId">
        <p style="margin-left: 1%; margin-bottom: 0.8%"><?php echo e($question->question); ?></p>
        <div id='options'>
          <div class='optionsSubSection1'>
           <div class='questionTextClass'>
            <input style="display:none" name="examid" value="<?php echo e($question->examid); ?>">
            <input style="display:none" name="marks" value="<?php echo e($question->marks); ?>">
            <input type='radio' name='option1_<?php echo e($questions); ?>' value='<?php echo e($question->option1); ?>'><span style='margin-left: 2%;'><?php echo e($question->option1); ?></span>
           </div>
           <div class='questionTextClass'>
            <input type='radio' name='option1_<?php echo e($questions); ?>' value='<?php echo e($question->option2); ?>'><span style='margin-left: 2%;'><?php echo e($question->option2); ?></span>
           </div>
          </div>
          <div class='optionsSubSection1'>
           <div class='questionTextClass'>
            <input type='radio' name='option1_<?php echo e($questions); ?>' value='<?php echo e($question->option3); ?>'><span style='margin-left: 2%;'><?php echo e($question->option3); ?></span>
           </div>
           <div class='questionTextClass'>
            <input type='radio' name='option1_<?php echo e($questions); ?>' value='<?php echo e($question->option4); ?>'><span style='margin-left: 2%;'><?php echo e($question->option4); ?></span>
           </div>
          </div>
        </div>
      </div>
  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <input style="display:none" name="numberofquestions" value="<?php echo e($questions); ?>">
            
        <div id="submitBtnDiv">
         <button type="submit" id="submitButton" value="<?php echo e($question->examid); ?>" class="btn btn-outline-success">Submit</button>
        </div>
        </form>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a)): ?>
<?php $component = $__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a; ?>
<?php unset($__componentOriginal6121507de807c98d4e75d845c5e3ae4201a89c9a); ?>
<?php endif; ?><?php /**PATH C:\Web developement_VS code\laravel\onlineExamProject\resources\views/exam.blade.php ENDPATH**/ ?>