<?php if (isset($component)) { $__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\AdminLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Admin\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('adminTitle', null, []); ?> Create Student <?php $__env->endSlot(); ?>
   <?php $__env->slot('css', null, []); ?> admin/css/createStudent.css <?php $__env->endSlot(); ?>
   <?php $__env->slot('adminBodyContent', null, []); ?> 
    <div id="createButtonStudentDiv">
      <button id="createStudentButton" type="button" class="btn btn-warning btn-lg">Create student</button>
    </div>

    <?php if(isset($e)): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Error!</strong>all fields must be require.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <form id="createStudentFormContainer" action="<?php echo e(route('createstudent')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <h2>Create new student</h2>
      <input type="text" required="required" class="createStudentInputFieldClass" name="fullname" placeholder="Full Name"> 
      <input type="email" required="required" class="createStudentInputFieldClass" placeholder="Email" name="email">
      <input type="text" required="required" class="createStudentInputFieldClass" name="class" placeholder="Class"> <input type="text"
        class="createStudentInputFieldClass" required="required" name="rollno" placeholder="Rollno">
      <input type="text" class="createStudentInputFieldClass" required="required" name="div" placeholder="Div"> <input type="text"
        class="createStudentInputFieldClass" name="dob" required="required" placeholder="Date of birth YYYY-MM-DD">
      <input type="password" required="required" class="createStudentInputFieldClass" name="password" placeholder="Password">

      <div id="submitButtonId">
        <button type="submit" class="btn btn-outline-success">Submit</button>
      </div>
    </form>

    <div id="studentListContainer">
     <h2 id="studentListContainerHeading">All students</h2>
     <div id="studentListHeading">
      <p class="studentListHeadingText">Name</p>
      <p class="studentListHeadingText">Rollno</p>
      <p class="studentListHeadingText">Class</p>
      <p class="studentListHeadingText">Division</p>
      <p class="studentListHeadingText">DOB</p>
     </div>

     <?php $__currentLoopData = $studentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="studentListCard">
        <p class="studentListCardData nameData"><?php echo e($data->name); ?></p>
        <p class="studentListCardData rollnoData"><?php echo e($data->rollno); ?></p>
        <p class="studentListCardData classData"><?php echo e($data->class); ?></p>
        <p class="studentListCardData divisionData"><?php echo e($data->div); ?></p>
        <p class="studentListCardData dobData"><?php echo e($data->dob); ?></p>
       </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
    </div>
   <?php $__env->endSlot(); ?>
   <?php $__env->slot('adminJs', null, []); ?> admin/js/createStudent.js <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451)): ?>
<?php $component = $__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451; ?>
<?php unset($__componentOriginal74bfb10f69c40670b2e07df59027d957824e0451); ?>
<?php endif; ?><?php /**PATH C:\Web developement_VS code\laravel\onlineExamProject\resources\views/admin/createStudent.blade.php ENDPATH**/ ?>