<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\homeController;
use App\Http\Controllers\examController;
use App\Http\Controllers\redirectController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\adminControllers\adminPanelControllers;
use App\Http\Controllers\adminControllers\createExamControllers;
use App\Http\Controllers\adminControllers\createStudentControllers;
use App\Http\Controllers\validateExamController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [homeController::class, 'show'])->middleware(['auth'])->name('home');

Route::post('/exam', [examController::class, 'submitexam'])->middleware(['auth'])->name('sumbitexam');
Route::get('/exam', [examController::class, 'submitexam'])->middleware(['auth'])->name('sumbitexam');

Route::get('/startexam', [examController::class, 'show'])->middleware(['auth'])->name('exam');
Route::post('/startexam', [examController::class, 'show'])->middleware(['auth'])->name('startexam');

Route::get('/adminpanel', [adminPanelControllers::class, 'show'])->middleware(['auth'])->name('adminpanel');

Route::get('/createexam', [createExamControllers::class, 'show'])->middleware(['auth'])->name('createexam');
Route::post('/createexam', [createExamControllers::class, 'createExam'])->middleware(['auth'])->name('createexam');

Route::get('/createstudent', [createStudentControllers::class, 'show'])->middleware(['auth'])->name('createstudent');
Route::post('/createstudent', [createStudentControllers::class, 'createStudent'])->middleware(['auth'])->name('createstudent');

Route::get('/redirect', [redirectController::class, 'redirect'])->middleware(['auth'])->name('redirect');

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';
