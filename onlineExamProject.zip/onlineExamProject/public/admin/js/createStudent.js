$(document).ready(function(e){
    
    var createStudentFormOpen = false;
   $("#createStudentButton").on("click", function(){
    // console.log("Click");
    // $("#createStudentFormContainer").css("display", "block");
    if(createStudentFormOpen == false){
        createStudentFormOpen = true;
        $("#createStudentFormContainer").slideToggle();
        $("#createStudentButton").text("Close");
        $("#createStudentButton").removeClass("btn-warning");
        $("#createStudentButton").addClass("btn btn-outline-danger");
    }else if(createStudentFormOpen == true){
        createStudentFormOpen = false;
        $("#createStudentFormContainer").slideToggle();
        $("#createStudentButton").text("Create student");
        $("#createStudentButton").removeClass("btn-danger");
        $("#createStudentButton").addClass("btn btn-outline-warning");
    }

    
   });

})