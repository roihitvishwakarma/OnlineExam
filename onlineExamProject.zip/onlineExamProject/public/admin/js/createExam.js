$(document).ready(function(e){
    
    $("#allStudents").on("click", function(){
        $("#specifyRollNumberDiv").css("display","none");
        // console.log($("#allStudents").val());
    });

    $("#customStudents").on("click", function(){
        $("#specifyRollNumberDiv").css("display","block");
        // console.log($("#customStudents").val());
    });
    var numberOfQuestion = 0;
    $("#addBtn").on("click", function(){
        numberOfQuestion = numberOfQuestion + 1;
        // console.log(numberOfQuestion);
        $("#submitButtonContainer").css("display", "block");
    $(".questionContainer").append("<div class='questionSubContainer'> <p class='questionNumbering'>"+numberOfQuestion+"</p> <input type='text' required='required' name='question"+numberOfQuestion+"' placeholder='Question' class='question'><input type='text' required='required' name='option"+numberOfQuestion+"_1' placeholder='Option-1' class='option' name='option'><input type='text' required='required' name='option"+numberOfQuestion+"_2' placeholder='Option-2' class='option' name='option'> <input type='text' required='required' name='option"+numberOfQuestion+"_3' placeholder='Option-3' class='option' name='option'> <input type='text' required='required' name='option"+numberOfQuestion+"_4' placeholder='Option-4' class='option' name='option'> <input type='text' required='required' name='answer"+numberOfQuestion+"' placeholder='Answer' class='option' name='answer'> </div>");
    $("#submitBtn").attr("value",numberOfQuestion);
  });
})