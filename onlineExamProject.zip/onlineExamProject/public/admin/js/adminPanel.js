$(document).ready(function(e){
    
$("#resultButton").on("click", function(){
    $(".viewButtonContainerView").slideToggle();
})

})