$(document).ready(function(e){
    
    // $("#startButton").on("click", function(){
    //     console.log($(this).data('examid'))
    // })
    // $(document).on("click", "#startButton", function(){
    //     // console.log($(this).data('examid'));
    //     var examid = $(this).data('examid');

    //     $.ajax({
    //         url:"php/startExam.php",
    //         method:"post",
    //         data:{examId:examid},
    //         success:function(response){
    //           console.log(response);
    //         }
    //     })
    // })
 })