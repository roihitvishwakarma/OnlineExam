$(document).ready(function(e){
    
   console.log("Exam Page");
})